const jwt = require('jsonwebtoken');

const token = jwt.sign({ userId: 1 }, 'your-secret-key', { expiresIn: '1h' });
console.log(token);
